#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
#define BST_Status int
#define ERROR 0
#define SUCCESS 1
#include "binary_sort_tree.h"

typedef int ElemType;
typedef Node Stacktype;

typedef  struct StackNode
{
	Stacktype *key;
	struct StackNode* next;
}StackNode, * LinkStackPtr;

typedef  struct  LinkStack
{
	LinkStackPtr top;
	int	count;
}LinkStack;



//��ջ
BST_Status initLStack(LinkStack* s);//��ʼ��ջ
BST_Status isEmptyLStack(LinkStack* s);//�ж�ջ�Ƿ�Ϊ��
BST_Status getTopLStack(LinkStack* s, Stacktype* e);//�õ�ջ��Ԫ��
BST_Status clearLStack(LinkStack* s);//���ջ
BST_Status destroyLStack(LinkStack* s);//����ջ
BST_Status LStackLength(LinkStack* s, int* length);//���ջ����
BST_Status pushLStack(LinkStack* s, Stacktype* data);//��ջ
BST_Status popLStack(LinkStack* s, Stacktype* data);//��ջ


#endif 
