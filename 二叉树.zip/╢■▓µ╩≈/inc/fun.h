#include "binary_sort_tree.h"
#include<Windows.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>


void menu();
void chose();
int getInt();
char* s_gets(char* st, int n);