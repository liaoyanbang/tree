﻿#include "binary_sort_tree.h"
#include "Stack.h"
#include "fun.h"
#include "AQueue.h"
#include <stdlib.h>
#include <stdio.h>
/**
 * BST initialize
 * @param BinarySortTreePtr BST
 * @return is complete
 */
BST_Status BST_init(BinarySortTreePtr t)
{
    Node* node = (Node*)malloc(sizeof(Node));//创建一个节点
    int num;
    printf("请输入树根：");
    num = getInt();
    //strcpy(num, node->value);
    node->left = NULL;
    node->right = NULL;
    node->value = num;
    t->root = node;
    return succeed;
}

/**
 * BST insert
 * @param BinarySortTreePtr BST
 * @param ElemType value to insert
 * @return is successful
 */
BST_Status BST_insert(BinarySortTreePtr t, ElemType num)//num 为getInit()
{
    NodePtr node = (NodePtr)malloc(sizeof(NodePtr*));//创建一个节点
    node->value = num;
    node->left = NULL;
    node->right = NULL;
    if (t->root == NULL)//判断树是不是空树
    {
        t->root = node;
    }
    else {//不是空树
        NodePtr temp = t->root;//从树根开始
        while (temp != NULL)
        {


            if (num < temp->value)//小于就进左儿子
            {
                if (temp->left == NULL)
                {
                    temp->left = node;
                    return succeed;
                }
                else {//继续判断
                    temp = temp->left;
                }
            }
            else {//否则进右儿子

                if (temp->right == NULL)
                {
                    temp->right = node;
                    return succeed;
                }
                else {//继续判断
                    temp = temp->right;
                }
            }
        }
    }
    return succeed;

}

/**
 * BST delete
 * @param BinarySortTreePtr BST
 * @param ElemType the value for Node which will be deleted
 * @return is successful
 */

 /*删除二叉树的节点*/
 /*删除逻辑：分三种情况删除：
  *第一种情况：若为叶子节点，直接删除（ 根叶子节点 要单独处理）
  *第二种情况：若该节点有一个子节点，左节点或右节点 。找到他的父节点，
  *让父节点指向左节点或右节点（若该节点为根，要单独处理 ）
  *第三种情况：有两个子节点   */
BST_Status BST_delete(BinarySortTreePtr t, ElemType num)
{
    NodePtr deleteNodePtr = t->root;
    NodePtr parentNodeOfDeletePtr = NULL;
    NodePtr substituteNodePtr;
    NodePtr parentNodeOfSubstitutePtr;

    //find deleNode and its parentNode
    while (deleteNodePtr != NULL &&num != deleteNodePtr->value)
    {
        parentNodeOfDeletePtr = deleteNodePtr;

        if (deleteNodePtr->value > num)
        {
            deleteNodePtr = deleteNodePtr->left;
        }
        else
        {
            deleteNodePtr = deleteNodePtr->right;
        }
    }

    //case that can't find such Node
    if (deleteNodePtr == NULL)
    {
        printf("没有找到该结点，无法删除\n\n");
        return failed;

    }

    //delete a leafNode
    if (deleteNodePtr->left == NULL && deleteNodePtr->right == NULL)
    {
        //delete Node is root
        if (parentNodeOfDeletePtr == NULL)
        {
            t->root = NULL;
        }
        else if (parentNodeOfDeletePtr->left == deleteNodePtr)
        {
            parentNodeOfDeletePtr->left = NULL;
        }
        else
        {
            parentNodeOfDeletePtr->right = NULL;
        }

    }
    //delete a Node which has a left child Node
    else if (deleteNodePtr->left != NULL && deleteNodePtr->right == NULL)
    {
        //delete Node is root
        if (parentNodeOfDeletePtr == NULL)
        {
             t->root= deleteNodePtr->left;
        }
        else if (parentNodeOfDeletePtr->right == deleteNodePtr)
            parentNodeOfDeletePtr->right = deleteNodePtr->left;
        else
            parentNodeOfDeletePtr->left = deleteNodePtr->left;

    }

    //delete a Node which has a right child Node
    else if (deleteNodePtr->left == NULL && deleteNodePtr->right != NULL)
    {
        //delete Node is root
        if (parentNodeOfDeletePtr == NULL)
        {
            t->root = deleteNodePtr->right;
        }
        else if (parentNodeOfDeletePtr->right == deleteNodePtr)
            parentNodeOfDeletePtr->right = deleteNodePtr->right;
        else
            parentNodeOfDeletePtr->left = deleteNodePtr->right;

    }
    //delete a Node which has a left and a right child Node
    else
    {
        parentNodeOfSubstitutePtr = deleteNodePtr;
        substituteNodePtr = deleteNodePtr->left;

        //search down and right to find substituteNode and its parentNode
        while (substituteNodePtr->right!= NULL)
        {
            parentNodeOfSubstitutePtr = substituteNodePtr;
            substituteNodePtr = substituteNodePtr->right;

        }

        //delete Node is root
        if (parentNodeOfDeletePtr == NULL)
        {
            t->root = substituteNodePtr;
        }
        else if (parentNodeOfDeletePtr->left == deleteNodePtr)
        {
            parentNodeOfDeletePtr->left = substituteNodePtr;
        }
        else
        {
            parentNodeOfDeletePtr->right = substituteNodePtr;
        }

        substituteNodePtr->right = deleteNodePtr->right;

        if (parentNodeOfSubstitutePtr != deleteNodePtr)
        {
            substituteNodePtr->left = deleteNodePtr->left;

            if (parentNodeOfSubstitutePtr->left == substituteNodePtr)
            {
                parentNodeOfSubstitutePtr->left = substituteNodePtr->left;
            }
            else
            {
                parentNodeOfSubstitutePtr->right = substituteNodePtr->left;
            }
        }

    }
    return succeed;
}

/**
 * BST search
 * @param BinarySortTreePtr BST
 * @param ElemType the value to search
 * @return is exist
 */
BST_Status BST_search(BinarySortTreePtr t, ElemType find)
{
    NodePtr node = (NodePtr)malloc(sizeof(NodePtr*));
    node = t->root;
    while (node!= NULL)
    {
        if(find == node->value)
            return SUCCESS;
    else if (find > node->value)
            node = node->right;
    else
            node = node->left;
    }
    return failed;

}

/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BST_Status BST_preorderI(BinarySortTreePtr t, void (*visit)(Node))
{
    SqStack topStack;
   // topLinkStack.top = NULL;
    if (initStack(&topStack,100) == 0)
        return failed;
    if (t->root == NULL)
        return failed;
    Node topNode;
    topNode.left = NULL;
    topNode.right = NULL;
    topNode.value = 0;
    pushStack(&topStack,t->root);
    while (popStack(&topStack,&topNode)) { //取栈顶元素，访问并出栈
        visit(topNode); //访问栈顶元素
        if (topNode.right != NULL) { //存在右结点，则先将右结点入栈。因为左结点先遍历
            pushStack(&topStack,topNode.right);
        }
        if (topNode.left != NULL) { //存在左结点，左结点入栈
            pushStack(&topStack,topNode.left);
        }
    }
    return succeed;
}

/**
 * BST preorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BST_Status BST_preorderR(BinarySortTreePtr t, void (*visit)(Node))
{
    if (t->root == NULL) {
        return failed;
    }
        visit(*(t->root));
        BST_preorderR(&t->root->left,visit);//遍历左子树
        BST_preorderR(&t->root->right,visit);//遍历右子树
        return succeed;
}

/**
 * BST inorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BST_Status BST_inorderI(BinarySortTreePtr t, void (*visit)(Node))
{
    SqStack topStack;
    if (initStack(&topStack,100) == 0)
        return failed;
    if (t->root == NULL)
        return failed;
    pushStack(&topStack,t->root);
    Node topNode;
    while (getTopStack(&topStack,&topNode))
    {//取栈顶结点
        //首先，一直遍历到最左边的结点
        while (topNode.left != NULL) { //左孩子结点不为空，入栈
            pushStack(&topStack,topNode.left);//左孩子结点入栈
            topNode = *(topNode.left); // 看下一个左孩子结点
        }
        //  * 其次，判断其是否存在右孩子 *不存在右孩子结点，直接将该结点出栈
        int flag = 1;
        while (flag && topNode.right == NULL)
        {//flag判断是否栈中还有数据 
            popStack(&topStack,&topNode);//出栈
            visit(topNode);
            flag = getTopStack(&topStack,&topNode);//取栈顶结点，继续判断
        }
        // 存在右孩子结点，当前结点出栈，并将右孩子结点入栈
        if (popStack(&topStack,&topNode)) {
            visit(topNode);
            pushStack(&topStack,topNode.right);
        }
    }
    return succeed;
}

/**
 * BST inorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BST_Status BST_inorderR(BinarySortTreePtr t, void (*visit)(Node))
{
    if (t->root == NULL) {
        return failed;
    }
    BST_inorderR(&t->root->left, visit);//遍历左子树
    visit(*(t->root));
    BST_inorderR(&t->root->right, visit);//遍历右子树
    return succeed;
}

/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BST_Status BST_postorderI(BinarySortTreePtr t, void (*visit)(Node))
{
    /**
     * 声明两个栈，遍历树的管理栈和备用栈
     * 备用栈的作用：部分结点存在两次访问的，备用栈是记录第一次访问，然后入栈。
     * 也可以在结点中添加一个标签记录访问次数，备用栈的设计是为了避免修改结点
     */
    SqStack stack,backup;
    if (initStack(&stack,50) == 0)
        return failed;
    if (initStack(&backup,50) == 0)
        return failed;
    if (t->root == NULL)
        return failed;
    pushStack(&stack,t->root);
    Node topNode; //记录当前栈顶结点
    Node backupNode; //记录备用栈的栈顶结点
    Node lastNode; //上次访问的结点
    topNode.left = NULL;
    topNode.right = NULL;
    topNode.value = 0;
    backupNode.left = NULL;
    backupNode.right = NULL;
    backupNode.value = 0;
    lastNode.left = NULL;
    lastNode.right = NULL;
    lastNode.value = 0;
    while (getTopStack(&stack,&topNode)) { //取栈顶结点
        int flag = getTopStack(&backup,&backupNode); //备用栈的栈顶元素,返回0表示备用栈为空。
        if (flag == 0 || compareTreeNode(topNode, backupNode) == 0) { //该结点是第一次访问
            if (topNode.left!= NULL && compareTreeNode(*(topNode.left), lastNode) == 0) { //左孩子结点不为空，且上次访问的不是左孩子结点
                pushStack(&stack,topNode.left); //左孩子结点入栈
                continue;
            }
            pushStack(&backup,&topNode);
            if (topNode.right != NULL && compareTreeNode(*topNode.right, lastNode) == 0) { //右孩子结点不为空，且上次访问的不是右孩子结点
                pushStack(&stack, topNode.right); //右孩子结点入栈
                continue;
            }
        }
        else { //该节结点是第二次访问，直接出栈
            popStack(&backup,&backupNode); //备用栈栈顶元素出栈
            popStack(&stack,&topNode); //当前栈栈顶元素出栈
            visit(topNode); //访问刚出栈的结点
            //lastNode = topNode; //记录刚刚访问的结点
            lastNode.left = topNode.left;
            lastNode.right = topNode.right;
            lastNode.value = topNode.value;
        }
    }
    return succeed;
}

/**
 * BST postorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BST_Status BST_postorderR(BinarySortTreePtr t, void (*visit)(Node))
{
    if (t->root == NULL) {
        return failed;
    }
    BST_postorderR(&t->root->left, visit);//遍历左子树
    BST_postorderR(&t->root->right, visit);//遍历右子树
    visit(*(t->root));
    return succeed;
}

/**
 * BST level order traversal
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BST_Status BST_levelOrder( BinarySortTreePtr t, void (*visit)(Node))
{
    AQueue queue; //创建队列
    InitAQueue(&queue);
    EnAQueue(&queue,t->root);//根结点入队
    Node node;
    node.left = NULL;
    node.right = NULL;
    node.value = 0;
    while (DeAQueue(&queue, &node)) {//队列中结点出队，队列为空，返回0，while循环结束
        visit(node);//访问队列中第一个结点
        if (node.left != NULL)//判断是否存在左孩子结点，将左孩子结点入队
            EnAQueue(&queue,(node.left));
        if (node.right != NULL)//判断是否存在右孩子结点，将右孩子结点入队
            EnAQueue(&queue,(node.right));
    }
    return succeed;
}

void visit(Node i) {
    printf("%d  ",i.value);
}

BST_Status compareTreeNode(Node i, Node j)
{
    if (i.value != j.value)
    {
        return failed;
    }
    else if (i.left != j.left)
    {
        return failed;
    }
    else if (i.right != j.right)
    {
        return failed;
    }
    else return succeed;
}

void outputTree(BinarySortTreePtr t, int spaces)
{
    int loop;

    while (t->root != NULL) {

        outputTree(&t->root->right, spaces + 4);

        for (loop = 1; loop <= spaces; loop++) {
            printf(" ");
        }

        printf("%d\n", t->root->value);

        outputTree(&t->root->left, spaces + 4);
        t->root = NULL;
    }
}
