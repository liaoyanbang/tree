#include<stdio.h>
#include<stdlib.h>
#include "fun.h"
int main()
{
	chose();
	system("pause");
}